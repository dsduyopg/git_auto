# 注意：不要覆盖 _prefix 宏，否则 _bindir / _unitdir / _sysconfdir 等
#       标准宏都会被连带改到错误路径。这里改用自定义宏 install_dir。
# 遵循 Fedora Packaging Guidelines：使用标准宏，不安装到 /opt。
%global install_dir %{_datadir}/git-autosync
%global _rpmlintrc %{name}.rpmlintrc

# _unitdir 宏由 systemd-rpm-macros 包提供（见 BuildRequires）。
# 若构建环境未安装该包，宏不会展开，这里回退到 systemd 标准单元目录，
# 保证跨环境可构建。
%if %{undefined _unitdir}
%global _unitdir /usr/lib/systemd/system
%endif

Name:           git-autosync
Version:        2.15
Release:        10%{?dist}
Summary:        Git automatic synchronization toolkit for local folders

License:        MIT
URL:            https://github.com/dsduyopg/git_auto
Source0:        https://github.com/dsduyopg/git_auto/releases/download/2.15-10/%{name}-%{version}.tar.gz
Source1:        git-autosync.rpmlintrc
# The source tarball checksum is published with each release; verify before building.

BuildArch:      noarch

Requires:       bash
Requires:       git
Requires:       inotify-tools
Requires:       systemd
Requires:       python3
Requires:       logrotate
# ssh-keygen is used by "git-autosync ssh-key" (menu item 2)
Requires:       openssh-clients
BuildRequires:  systemd-rpm-macros
%{?systemd_requires}

%description
Git AutoSync is a Linux tool that automatically syncs local folders to Gitee /
GitHub repositories. It is a systemd + inotify port of the original Windows
(PowerShell + NSSM) design.

Features:
- Real-time two-way sync (watch -> commit -> push / pull)
- systemd timer for periodic pull
- One-shot service install / repair / rebuild / uninstall
- Email notification on success / failure (optional, off by default)
- Auto-cleanup of stale index.lock to avoid sync stalls
- Runs on RHEL / CentOS / Fedora / AlmaLinux / Rocky

%prep
%setup -q

%build
# 纯 Shell 脚本，无需编译

%check
# 语法自检：确保所有 shell 脚本无语法错误
for f in bin/* lib/*.sh; do
    bash -n "$f" || { echo "syntax error: $f"; exit 1; }
done

%install
rm -rf %{buildroot}

# 程序主体（LICENSE 由 license 宏单独安装，此处不复制以免文件重复）
# 源码来自 Windows 文件系统时 LICENSE 会带可执行位，若不去掉，rpmlint 会报
# script-without-shebang；这里统一收紧为 0644
chmod 0644 LICENSE
mkdir -p %{buildroot}%{install_dir}
cp -r bin lib systemd %{buildroot}%{install_dir}/
cp README.md VERSION.txt %{buildroot}%{install_dir}/
cp install.sh uninstall.sh %{buildroot}%{install_dir}/
if [ -d docs ]; then cp -r docs %{buildroot}%{install_dir}/; fi
chmod 0755 %{buildroot}%{install_dir}/bin/*
chmod 0644 %{buildroot}%{install_dir}/lib/*.sh
chmod 0644 %{buildroot}%{install_dir}/systemd/*

# logrotate 配置（防止 /var/log/git-autosync 下日志无限增长）
mkdir -p %{buildroot}%{_sysconfdir}/logrotate.d
install -m 0644 logrotate/git-autosync %{buildroot}%{_sysconfdir}/logrotate.d/git-autosync

# 命令入口
mkdir -p %{buildroot}%{_bindir}
ln -sf ../share/git-autosync/bin/git-autosync %{buildroot}%{_bindir}/git-autosync

# systemd 单元
mkdir -p %{buildroot}%{_unitdir}
cp systemd/git-autosync@.service      %{buildroot}%{_unitdir}/
cp systemd/git-autosync-fetch.service %{buildroot}%{_unitdir}/
cp systemd/git-autosync-fetch.timer   %{buildroot}%{_unitdir}/

# 配置与日志目录
mkdir -p %{buildroot}%{_sysconfdir}/git-autosync/repos
mkdir -p %{buildroot}%{_localstatedir}/log/git-autosync

# man 手册页
mkdir -p %{buildroot}%{_mandir}/man1
gzip -c man/git-autosync.1 > %{buildroot}%{_mandir}/man1/git-autosync.1.gz
chmod 0644 %{buildroot}%{_mandir}/man1/git-autosync.1.gz

%files
%license LICENSE
%{install_dir}
%{_bindir}/git-autosync
%{_unitdir}/git-autosync@.service
%{_unitdir}/git-autosync-fetch.service
%{_unitdir}/git-autosync-fetch.timer
%dir %{_sysconfdir}/git-autosync
%attr(0700, root, root) %dir %{_sysconfdir}/git-autosync/repos
%dir %{_localstatedir}/log/git-autosync
%{_mandir}/man1/git-autosync.1.gz
%config(noreplace) %{_sysconfdir}/logrotate.d/git-autosync

%post
%systemd_post git-autosync-fetch.service git-autosync-fetch.timer
# Refresh runtime unit copies created by the toolkit so an upgrade does
# not leave stale unit files under /etc/systemd/system.
if [ -d %{_sysconfdir}/systemd/system ]; then
    install -m 0644 %{install_dir}/systemd/git-autosync@.service \
        %{_sysconfdir}/systemd/system/ 2>/dev/null || :
    install -m 0644 %{install_dir}/systemd/git-autosync-fetch.service \
        %{_sysconfdir}/systemd/system/ 2>/dev/null || :
    if [ -f %{_sysconfdir}/systemd/system/git-autosync-fetch.timer ]; then
        sed -i 's|^Description=.*|Description=Git AutoSync scheduled mirror pull|' \
            %{_sysconfdir}/systemd/system/git-autosync-fetch.timer
    else
        install -m 0644 %{install_dir}/systemd/git-autosync-fetch.timer \
            %{_sysconfdir}/systemd/system/ 2>/dev/null || :
    fi
    systemctl daemon-reload 2>/dev/null || :
fi
echo "git-autosync has been installed."
echo "  Run: sudo git-autosync          # interactive main menu"
echo "       sudo git-autosync env      # environment check"

%preun
if [ "$1" -eq 0 ]; then
    # 卸载前停止并禁用所有已登记的 per-repo 实例
    for c in %{_sysconfdir}/git-autosync/repos/*.conf; do
        [ -f "$c" ] || continue
        n=$(basename "$c" .conf)
        systemctl stop "git-autosync@${n}.service" >/dev/null 2>&1 || :
        systemctl disable "git-autosync@${n}.service" >/dev/null 2>&1 || :
    done
    # Remove runtime unit copies created by the toolkit so dnf remove
    # does not leave stale units behind.
    rm -f %{_sysconfdir}/systemd/system/git-autosync@.service \
          %{_sysconfdir}/systemd/system/git-autosync-fetch.service \
          %{_sysconfdir}/systemd/system/git-autosync-fetch.timer
    systemctl daemon-reload >/dev/null 2>&1 || :
fi
%systemd_preun git-autosync-fetch.service git-autosync-fetch.timer

%postun
%systemd_postun_with_restart git-autosync-fetch.service git-autosync-fetch.timer

%changelog
* Wed Sep 02 2026 wowsony <dsduyopg@github.com> - 2.15-10
- Add missing runtime dependency: openssh-clients (ssh-keygen is
  required by "git-autosync ssh-key")
- Rename bundled docs to ASCII filenames (manual.md, getting-started.md)
  and update the man page reference accordingly
- Fix rpmlint: drop the shebang from the sourced libraries
  (lib/common.sh, lib/i18n.sh) and set LICENSE to 0644
* Wed Sep 02 2026 wowsony <dsduyopg@github.com> - 2.15-9
- i18n: env / sync / fetch / mail sub-commands now output English;
  the main menu keeps its bilingual mode (English default, Chinese optional)
- i18n: added the missing translation entries for sub-command titles
  and the language menu
* Wed Sep 02 2026 wowsony <dsduyopg@github.com> - 2.15-8
- Fix: menu item "Email notification" failed with "No such file or
  directory"; cmd_mail() now invokes git-autosync-mail-config
* Tue Sep 01 2026 wowsony <dsduyopg@github.com> - 2.15-7
- i18n: default English UI with optional Chinese mode
- man page translated to English, install paths updated
- English Summary
- rpmlint: suppress false spelling-error warnings
* Tue Sep 01 2026 wowsony <dsduyopg@github.com> - 2.15-1
- Initial Linux release, ported from Windows v2.15
- Follow Fedora Packaging Guidelines: use /usr/share standard paths, add logrotate
- Replace NSSM with systemd and FileSystemWatcher with inotifywait
- Include Chinese user manual and man page
- Provide bilingual %%description for i18n review
